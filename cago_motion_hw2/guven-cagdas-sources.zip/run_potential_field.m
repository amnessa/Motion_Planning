% run_potential_field.m
function results = run_potential_field(start, goal, obstacles, world_center, world_radius, epsilon_q, epsilon_r)
    % Simulation time is 1000 sec we can lower this and increase lambda to
    % decrease computation time
    tspan = linspace(0, 1000, 2000);
    lambda = 0.5;  % Step size for gradient descent
    %lambda = 0.1 + 0.4 * exp(-norm(q - goal)); %adaptive version example of a decaying step size
    
    options = odeset('RelTol', 1e-2, ...
                    'AbsTol', 1e-2, ...
                    'MaxStep', 0.01, ...
                    'InitialStep', 0.005, ...
                    'Events', @(t,q) collision_event(t, q, obstacles));
   
    odefun = @(t,q) steepest_descent_step(q, goal, obstacles, world_center, world_radius, epsilon_q, epsilon_r, lambda);
    
    [t, q] = ode45(odefun, tspan, start, options);
    
    results.time = t;
    results.path = q;
    results.type = 'Potential Fields';
end
function qdot = steepest_descent_step(q, goal, obstacles, world_center, world_radius, epsilon_q, epsilon_r, lambda)
    % Get the gradient
    grad = potential_fields(q, goal, obstacles, world_center, world_radius, epsilon_q, epsilon_r);
    
    % Normalize gradient and apply step size
    grad_norm = norm(grad);
    if grad_norm > 0
        qdot = -lambda * grad / grad_norm;
    else
        qdot = zeros(size(q));
    end
end